﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnInserir2_Click(object sender, EventArgs e)
        
        {
            string palavra1 = txtPalavra1.Text;

            int meio = palavra1.Length / 2;


            string resultado = palavra1.Insert(meio, "**");


            txtPalavra2.Text = resultado;
        }

        

        private void txtPalavra2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCompara_Click(object sender, EventArgs e)
        {
 
            string palavra1 = txtPalavra1.Text;
            string palavra2 = txtPalavra2.Text;

            if (palavra1 == palavra2)
            {
                MessageBox.Show("Sim, são iguais!");
            }
            else
            {
                MessageBox.Show("Não, são diferentes!");
            }
        }

        private void tnbInserir1_Click(object sender, EventArgs e)
        {
            string palavra1 = txtPalavra1.Text;
            string palavra2 = txtPalavra2.Text;

            int meio = palavra2.Length / 2;


            string resultado = palavra2.Insert(meio, palavra1);


            txtPalavra2.Text = resultado;
        }

    }
}


