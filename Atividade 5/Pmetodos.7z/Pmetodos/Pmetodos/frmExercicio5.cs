﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            // Tenta converter o texto dos TextBox para números inteiros
            bool ok1 = int.TryParse(txtNum1.Text, out int num1);
            bool ok2 = int.TryParse(txtNum2.Text, out int num2);

            // Verifica se as conversões deram certo
            if (!ok1 || !ok2)
            {
                MessageBox.Show("Digite apenas números válidos nos dois campos!");
                return;
            }
            if (num2 <= num1)
            {
                MessageBox.Show("Erro: o segundo número deve ser MAIOR que o primeiro!");
                return;
            }

            Random rnd = new Random();

            int sorteado = rnd.Next(num1, num2 + 1);


            MessageBox.Show("Número sorteado: " + sorteado);
        }

    }
}

