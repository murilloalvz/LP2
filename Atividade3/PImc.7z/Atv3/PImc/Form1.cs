﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double peso, altura;

        private void mskAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskAltura.Text, out altura )|| altura<=0)
            {
                errorProvider1.SetError(mskAltura, "Altura Inválido");
                mskPeso.Focus();
            }
            else
            {
                errorProvider1.SetError(mskAltura, "");
            }
        }

        private void btnLimpar_Validated(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskAltura.Clear();
            mskPeso.Clear();
            txtIMC.Clear();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double imc;
            altura = Math.Pow(altura, 2);
            txtIMC.Text = (peso / altura).ToString("N2");
            Double.TryParse(txtIMC.Text, out imc);
            if (imc < 18.5)
            {
                MessageBox.Show("Magreza");
            }
            else if (imc < 24.9)
            {
                MessageBox.Show("Normal");
            }
            else if (imc < 25.0)
            {
                MessageBox.Show("Sobrepeso " + "Obesidade Grau I");
            }
            else if (imc < 29.9)
            {
                MessageBox.Show("Obesidade " + "Obeidade Grau II");
            }
            else
            {
                MessageBox.Show("Obesidade Grave " + "Obesidade Grau III");
            }
        }


        private void txtIMC_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtIMC_Validated(object sender, EventArgs e)
        {

        }

        private void mskPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskPeso.Text, out peso )|| peso<=0)
            {
                errorProvider1.SetError(mskPeso, "Peso Inválido");
                mskPeso.Focus();
            }
            else
            {
                errorProvider1.SetError(mskPeso, "");
            }
        }

        private void mskPeso_Validating(object sender, CancelEventArgs e)
        {
            
                      }

        private void mskPeso_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
