﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Eventos click
        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listBoxNotas.Items.Clear();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {

            Double[,] filmeNotas = new Double[3, 2];
            string auxiliar = "";


            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    auxiliar = Interaction.InputBox($"Pessoa {i + 1}, Digite a nota do filme {j + 1}", "Entrada de Dados");

                    if (!double.TryParse(auxiliar, out filmeNotas[i, j]) ||
                        filmeNotas[i, j] > 10 ||
                        filmeNotas[i, j] < 0
                        )
                    {
                        MessageBox.Show("Nota inválida");
                        j--;
                    }

                    if (auxiliar == "")
                    {
                        break;
                    }
                }
            }

            ArrayList notasFinais1 = new ArrayList();

                double mediaFilme1 = 0.0;
                double mediaFilme2 = 0.0;


            for (int k = 0; k < 3; k++)
            {
                notasFinais1.Add($"Pessoa {k + 1}: " +
                $"Nota filme 1: {filmeNotas[k, 0].ToString("F2")} " +
                $"Nota filme 2: {filmeNotas[k, 1].ToString("F2")} ") ;
                
                
                mediaFilme1 += ((filmeNotas[k, 0]) + (filmeNotas[k, 0]) + (filmeNotas[k, 0]) / 3);
                mediaFilme2 += ((filmeNotas[k, 1]) + (filmeNotas[k, 1]) + (filmeNotas[k, 1]) / 3);

            listBoxNotas.Items.Add(notasFinais1[k]);
            }

            listBoxNotas.Items.Add("Média do Filme 1:" + (mediaFilme1).ToString());
            listBoxNotas.Items.Add("Média do Filme 2:" + (mediaFilme2).ToString());

        }

    }
}
