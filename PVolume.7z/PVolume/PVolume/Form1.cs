﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        double raio, altura, volume;
        public Form1()
        {
            InitializeComponent();
        }

        private void TxtRaio_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(TxtRaio.Text, out raio) || raio <= 0)
            {
                MessageBox.Show("Raio inválido!!!");
            }
            
        }

        private void TxtAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(TxtAltura.Text, out altura) || altura <= 0)
            {
                MessageBox.Show("Altura inválida!!!");
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            TxtRaio.Clear();
            TxtAltura.Clear();
            TxtVolume.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(TxtRaio.Text, out raio) || (raio <= 0))
            {
                MessageBox.Show("raio inválido!!");
                TxtRaio.Focus();
            }
            else if (!Double.TryParse(TxtAltura.Text, out altura) || (altura <= 0))
            {
                MessageBox.Show("altura inválida!!");
                TxtAltura.Focus();
            }
            else
            {
                volume = Math.PI * Math.Pow(raio, 2) * altura;
                TxtVolume.Text = volume.ToString("N2");
            }

                
        }
    }
}
