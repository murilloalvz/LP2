﻿namespace PVolume
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnCalcular = new System.Windows.Forms.Button();
            this.BtnLimpar = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.LblRaio = new System.Windows.Forms.Label();
            this.LblAltura = new System.Windows.Forms.Label();
            this.LblVolume = new System.Windows.Forms.Label();
            this.TxtAltura = new System.Windows.Forms.TextBox();
            this.TxtVolume = new System.Windows.Forms.TextBox();
            this.TxtRaio = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // BtnCalcular
            // 
            this.BtnCalcular.Location = new System.Drawing.Point(184, 522);
            this.BtnCalcular.Name = "BtnCalcular";
            this.BtnCalcular.Size = new System.Drawing.Size(198, 93);
            this.BtnCalcular.TabIndex = 0;
            this.BtnCalcular.Text = "Calcular";
            this.BtnCalcular.UseVisualStyleBackColor = true;
            this.BtnCalcular.Click += new System.EventHandler(this.BtnCalcular_Click);
            // 
            // BtnLimpar
            // 
            this.BtnLimpar.Location = new System.Drawing.Point(582, 522);
            this.BtnLimpar.Name = "BtnLimpar";
            this.BtnLimpar.Size = new System.Drawing.Size(188, 93);
            this.BtnLimpar.TabIndex = 1;
            this.BtnLimpar.Text = "Limpar";
            this.BtnLimpar.UseVisualStyleBackColor = true;
            this.BtnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(980, 522);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(186, 93);
            this.button3.TabIndex = 2;
            this.button3.Text = "Fechar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // LblRaio
            // 
            this.LblRaio.AutoSize = true;
            this.LblRaio.Location = new System.Drawing.Point(83, 136);
            this.LblRaio.Name = "LblRaio";
            this.LblRaio.Size = new System.Drawing.Size(42, 20);
            this.LblRaio.TabIndex = 3;
            this.LblRaio.Text = "Raio";
            // 
            // LblAltura
            // 
            this.LblAltura.AutoSize = true;
            this.LblAltura.Location = new System.Drawing.Point(83, 202);
            this.LblAltura.Name = "LblAltura";
            this.LblAltura.Size = new System.Drawing.Size(51, 20);
            this.LblAltura.TabIndex = 4;
            this.LblAltura.Text = "Altura";
            // 
            // LblVolume
            // 
            this.LblVolume.AutoSize = true;
            this.LblVolume.Location = new System.Drawing.Point(83, 279);
            this.LblVolume.Name = "LblVolume";
            this.LblVolume.Size = new System.Drawing.Size(63, 20);
            this.LblVolume.TabIndex = 5;
            this.LblVolume.Text = "Volume";
            // 
            // TxtAltura
            // 
            this.TxtAltura.Location = new System.Drawing.Point(204, 199);
            this.TxtAltura.Name = "TxtAltura";
            this.TxtAltura.Size = new System.Drawing.Size(210, 26);
            this.TxtAltura.TabIndex = 6;
            this.TxtAltura.Validated += new System.EventHandler(this.TxtAltura_Validated);
            // 
            // TxtVolume
            // 
            this.TxtVolume.Location = new System.Drawing.Point(204, 276);
            this.TxtVolume.Name = "TxtVolume";
            this.TxtVolume.Size = new System.Drawing.Size(210, 26);
            this.TxtVolume.TabIndex = 7;
            // 
            // TxtRaio
            // 
            this.TxtRaio.Location = new System.Drawing.Point(204, 130);
            this.TxtRaio.Name = "TxtRaio";
            this.TxtRaio.Size = new System.Drawing.Size(210, 26);
            this.TxtRaio.TabIndex = 8;
            this.TxtRaio.Validated += new System.EventHandler(this.TxtRaio_Validated);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1256, 667);
            this.Controls.Add(this.TxtRaio);
            this.Controls.Add(this.TxtVolume);
            this.Controls.Add(this.TxtAltura);
            this.Controls.Add(this.LblVolume);
            this.Controls.Add(this.LblAltura);
            this.Controls.Add(this.LblRaio);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.BtnLimpar);
            this.Controls.Add(this.BtnCalcular);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnCalcular;
        private System.Windows.Forms.Button BtnLimpar;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label LblRaio;
        private System.Windows.Forms.Label LblAltura;
        private System.Windows.Forms.Label LblVolume;
        private System.Windows.Forms.TextBox TxtAltura;
        private System.Windows.Forms.TextBox TxtVolume;
        private System.Windows.Forms.TextBox TxtRaio;
    }
}

