﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            //if (!Double.TryParse(txtNumero2.Text, out numero2))
            //{
            //    errorProvider2.SetError(txtNumero2, "Número 2 inválido");
            //    txtNumero2.Focus();
            //}
            //else
            //    errorProvider2.SetError(txtNumero2, "");
            try
            {
                errorProvider2.SetError(txtNumero2, "");
                numero2 = Convert.ToDouble(txtNumero2.Text);
            }
            catch (Exception)
            {
                errorProvider2.SetError(txtNumero2, "Número 2 Inválido");
                txtNumero2.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?",
                "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                Close();
            }

        }

        private void btnSoma_Click(object sender, EventArgs e)
        {

            txtResultado.Text = (numero1 + numero2).ToString("N10");
        }

        private void btnSubtração_Click(object sender, EventArgs e)
        {
            txtResultado.Text = (numero1 - numero2).ToString("N10");
        }

        private void btnMultiplicação_Click(object sender, EventArgs e)
        {
            txtResultado.Text = (numero1 * numero2).ToString("N10");
        }

        private void btnDivisão_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("Não é possível dividir por 0!");
            }
            else
                txtResultado.Text = (numero1 / numero2).ToString("N10");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1))
            {
                errorProvider1.SetError(txtNumero1, "Número 1 inválido");
                txtNumero1.Focus();
            }
            else
                errorProvider1.SetError(txtNumero1, "");
        }
    }
}
